﻿public enum ObjectTypes
{
  Wall, Door, Pickup, Destructable
}
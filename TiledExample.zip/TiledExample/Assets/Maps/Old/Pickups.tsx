<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="BaseSet2" tilewidth="16" tileheight="16" spacing="1" tilecount="522" columns="29">
 <image source="Resources/roguelikeDungeon_transparent.png" width="492" height="305"/>
 <tile id="21">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="2"/>
   <property name="DoorPositionX" type="int" value="1"/>
   <property name="DoorPositionY" type="int" value="2"/>
   <property name="DoorWidth" type="int" value="2"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="2"/>
   <property name="DoorPositionX" type="int" value="2"/>
   <property name="DoorPositionY" type="int" value="2"/>
   <property name="DoorWidth" type="int" value="2"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="2"/>
   <property name="DoorPositionX" type="int" value="1"/>
   <property name="DoorPositionY" type="int" value="1"/>
   <property name="DoorWidth" type="int" value="2"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="2"/>
   <property name="DoorPositionX" type="int" value="2"/>
   <property name="DoorPositionY" type="int" value="1"/>
   <property name="DoorWidth" type="int" value="2"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="311">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="1"/>
   <property name="DoorPositionY" type="int" value="3"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="312">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="2"/>
   <property name="DoorPositionY" type="int" value="3"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="313">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="3"/>
   <property name="DoorPositionY" type="int" value="3"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="340">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="1"/>
   <property name="DoorPositionY" type="int" value="2"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="341">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="2"/>
   <property name="DoorPositionY" type="int" value="2"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="342">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="3"/>
   <property name="DoorPositionY" type="int" value="2"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="369">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="1"/>
   <property name="DoorPositionY" type="int" value="1"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="370">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="2"/>
   <property name="DoorPositionY" type="int" value="1"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="371">
  <properties>
   <property name="Destroyable" type="bool" value="true"/>
   <property name="DoorHeight" type="int" value="3"/>
   <property name="DoorPositionX" type="int" value="3"/>
   <property name="DoorPositionY" type="int" value="1"/>
   <property name="DoorWidth" type="int" value="3"/>
   <property name="Type" value="Door"/>
  </properties>
 </tile>
 <tile id="480">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="481">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="482">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="483">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="484">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="509">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="510">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="511">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="512">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
 <tile id="513">
  <properties>
   <property name="Type" value="Wall"/>
  </properties>
 </tile>
</tileset>
